python ./evo/evaluate_ate.py --verbose --plot Results.png ./gt_ok.txt ./line1.txt
