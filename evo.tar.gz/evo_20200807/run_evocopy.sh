python ./evo/evaluate_ate.py --verbose --plot Resultscopy.png ./FrameTrajectory_TUM_Format.txt ./state.txt
